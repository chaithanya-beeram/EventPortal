<?php
$con = mysqli_connect("localhost","cpb9792_root","chaithuB2316.","cpb9792_test");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>